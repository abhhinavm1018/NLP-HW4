# tests

These tests only verify that your environment is set up correctly, and that your
models follow the bare minimum API. 

**Passing these tests is in no way a guarantee that your model is implemented
correctly**
